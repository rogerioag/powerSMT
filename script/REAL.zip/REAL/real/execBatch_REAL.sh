#!/bin/bash
echo "Execution in Batch."
echo "Execution RUN_PS_REAL_EXP4_SMT_4.sh"
/dados/desenvolvimento/projetos.eclipse/projetos.cpp/powerSMT_impl_v_7/script/REAL/real/RUN_PS_REAL_EXP4_SMT_4.sh

echo "Execution RUN_PS_REAL_EXP4_SMT_1.sh"
/dados/desenvolvimento/projetos.eclipse/projetos.cpp/powerSMT_impl_v_7/script/REAL/real/RUN_PS_REAL_EXP4_SMT_1.sh

echo "Execution RUN_PS_REAL_EXP4_SMT_2.sh"
/dados/desenvolvimento/projetos.eclipse/projetos.cpp/powerSMT_impl_v_7/script/REAL/real/RUN_PS_REAL_EXP4_SMT_2.sh

echo "Execution RUN_PS_REAL_EXP4_SMT_8.sh"
/dados/desenvolvimento/projetos.eclipse/projetos.cpp/powerSMT_impl_v_7/script/REAL/real/RUN_PS_REAL_EXP4_SMT_8.sh

echo "Execution RUN_PS_REAL_EXP4_SMT_16.sh"
/dados/desenvolvimento/projetos.eclipse/projetos.cpp/powerSMT_impl_v_7/script/REAL/real/RUN_PS_REAL_EXP4_SMT_16.sh

echo "End of Execution in Batch."
